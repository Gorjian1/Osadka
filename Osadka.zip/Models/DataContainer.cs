﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Osadka.Models
{
    public partial class DataContainer
    {
        public List <float> Data { get; set; }
    }
}
