﻿
namespace Osadka.Models
{
    public record DataPoint(double X, double Y, double Z);
}
